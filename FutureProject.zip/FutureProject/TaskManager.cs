using System;
using System.Collections.Generic;

namespace FutureProject
{
    public class TaskManager
    {
        private List<Task> tasks;

        public TaskManager()
        {
            tasks = new List<Task>();
        }

        public void AddTask(Task task)
        {
            tasks.Add(task);
        }

        public void ViewTasks()
        {
            if (tasks.Count == 0)
            {
                Console.WriteLine("No tasks available.");
                return;
            }

            foreach (var task in tasks)
            {
                Console.WriteLine(task);
            }
        }

        public void DeleteTask(int id)
        {
            Task taskToRemove = tasks.Find(task => task.Id == id);
            if (taskToRemove != null)
            {
                tasks.Remove(taskToRemove);
            }
            else
            {
                Console.WriteLine("Task not found.");
            }
        }
    }
}