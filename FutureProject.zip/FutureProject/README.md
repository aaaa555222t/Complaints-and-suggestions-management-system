# Task Manager

This is a basic C# application to manage tasks.

## Features
- Add a new task
- View all tasks
- Delete a task by ID

## How to Run
1. Clone the repository.
2. Open the solution in Visual Studio or VS Code.
3. Run the `Program.cs` file.

## Team Members
- Ahmed
- Yazeed
