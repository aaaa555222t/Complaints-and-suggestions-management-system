using System;

namespace FutureProject
{
    public class Task
    {
        public int Id { get; private set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public static int Counter = 0;

        public Task(string name, string description)
        {
            Id = ++Counter;
            Name = name;
            Description = description;
        }

        public override string ToString()
        {
            return $"ID: {Id}, Name: {Name}, Description: {Description}";
        }
    }
}