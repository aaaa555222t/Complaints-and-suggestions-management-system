using System;

namespace FutureProject
{
    class Program
    {
        static void Main(string[] args)
        {
            TaskManager taskManager = new TaskManager();
            Console.WriteLine("Welcome to the Task Manager!");

            while (true)
            {
                Console.WriteLine("\nChoose an option:");
                Console.WriteLine("1. Add Task");
                Console.WriteLine("2. View Tasks");
                Console.WriteLine("3. Delete Task");
                Console.WriteLine("4. Exit");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Enter task name: ");
                        string name = Console.ReadLine();
                        Console.Write("Enter task description: ");
                        string description = Console.ReadLine();
                        taskManager.AddTask(new Task(name, description));
                        Console.WriteLine("Task added successfully!");
                        break;

                    case "2":
                        Console.WriteLine("\nTasks:");
                        taskManager.ViewTasks();
                        break;

                    case "3":
                        Console.Write("Enter task ID to delete: ");
                        int id = int.Parse(Console.ReadLine());
                        taskManager.DeleteTask(id);
                        Console.WriteLine("Task deleted successfully!");
                        break;

                    case "4":
                        Console.WriteLine("Exiting... Goodbye!");
                        return;

                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }
    }
}